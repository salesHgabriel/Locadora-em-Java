/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author gabriel
 */
public class ModelConexaoBD {
   
   public  Statement stm; // Responsavel pela pesquisa do BD
   public  ResultSet rs; // Responsavel pela armazenamento da pesquisa
   private String driver = "org.mysql.jdbc.Driver"; // Responsavel pela identificação do servico    
   private String caminho = "jdbc:mysql://localhost:3306/locadora05"; // (caminho)onde esta o DB
   private String usuario = "root"; // usuario padrao quando instalou BD
   private String senha = ""; //senha quando instalou BD
   public Connection con; //Responsavel pela conexão
          
   public void conexao(){
       try {
           System.setProperty("org.mysql.jdbc.Driver", driver);
           con = DriverManager.getConnection(caminho, usuario, senha);
           //JOptionPane.showMessageDialog(null, "Conexao efeutada com sucesso");
       } catch (SQLException ex) {
          JOptionPane.showMessageDialog(null, "Erro ao se conectar com banco de dados\n "+ex.getMessage());
       }
    }   
   
      
   public void executaSql(String sql){
       try {
           stm = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        rs = stm.executeQuery(sql);
       } catch (SQLException ex) {
         JOptionPane.showMessageDialog(null, "Erro no executa sql\n "+ex.getMessage());
       }
     
       
   
   
   }
   
    
   
   
   
      public void desconecta(){
   
       try {
           con.close();
          // JOptionPane.showMessageDialog(null, "Banco de dados desconectado");
       } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Erro ao fechar conexão do banco de dados\n" +ex.getMessage());
       }
       
   }
   
}
