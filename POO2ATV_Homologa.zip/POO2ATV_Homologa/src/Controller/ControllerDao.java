/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.UsuariosModel;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
// driver de conexão SQL para Java 
import java.sql.SQLException; 
/**
 *
 * @author gabriel
 */
public class ControllerDao {
    ModelConexaoBD conex = new ModelConexaoBD();
    UsuariosModel mod = new UsuariosModel();
    
    
    
    public void Salvar(UsuariosModel mod){
        conex.conexao();
        try {
            PreparedStatement stmt = conex.con.prepareStatement("insert into chamados (nome, email, obs)  values (?,?,?)");
            stmt.setString(1, mod.getObs());
            stmt.setString(2, mod.getNome());
            stmt.setString(3, mod.getEmail());
            
            
           // stmt.setString(4, mod.getSenha());
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Valores inseridos com sucesso ! ");
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Dados nao inseridos"+ex);
           }
        
        
        
        conex.desconecta();
    
    }
    
    
    public UsuariosModel buscaUsuario (UsuariosModel mod){
            conex.conexao();
            conex.executaSql("SELECT *  FROM user WHERE nome LIKE '%"+mod.getPesquisa()+"%'");
            
            try {
                conex.rs.first();
                mod.setNome(conex.rs.getString("nome"));
               // mod.setLogin(conex.rs.getString("login"));
                        
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "Usuario não encontrado"+e.getMessage());
            
        }
            conex.desconecta();
            return mod;
        
	}
        
       public void Comprar(Model.ModelFilme mod){
        conex.conexao();
        try {
            PreparedStatement stmt = conex.con.prepareStatement("insert into filmes_vendidos (grade_filmes_nome,pagamento)  values (?,?)");
            stmt.setString(1, mod.getNome_filme());
            stmt.setString(2, mod.getPagamento());
          //  stmt.setString(3, mod.getEmail());
            
            
           // stmt.setString(4, mod.getSenha());
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Valores inseridos com sucesso ! ");
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Dados nao inseridos"+ex);
           }
        
        
        
        conex.desconecta();
    
    }
    
      public UsuariosModel buscaFilme (UsuariosModel mod){
            conex.conexao();
            conex.executaSql("SELECT *  FROM grade_filmes WHERE nome_filme LIKE '%"+mod.getPesquisa()+"%'");
            
            try {
                conex.rs.first();
                mod.setNome(conex.rs.getString("nome_filme"));
               // mod.setLogin(conex.rs.getString("login"));
                        
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "Usuario não encontrado"+e.getMessage());
            
        }
            conex.desconecta();
            return mod;
        
	}
        
        
        
        public void SalvarUser(UsuariosModel mod){
        conex.conexao();
        try {
            PreparedStatement stmt = conex.con.prepareStatement("insert into user (nome,senha,end,cpf)  values (?,?,?,?)");
            stmt.setString(1, mod.getNome());
            stmt.setString(2, mod.getSenha());
            stmt.setString(3, mod.getEndereco());
            stmt.setString(4, mod.getCpf());
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Valores inseridos com sucesso ! ");
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Dados nao inseridos"+ex);
           }
        
        
        
        conex.desconecta();
    
    }
        

}
